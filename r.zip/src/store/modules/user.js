import router from '@/router'
import { ElMessageBox, } from 'element-plus'
import { login, logout, getInfo } from '@/api/login'
import { getToken, setToken, removeToken } from '@/utils/auth'
import { isHttp, isEmpty } from "@/utils/validate"
import useLockStore from '@/store/modules/lock'
import defAva from '@/assets/images/profile.jpg'

const useUserStore = defineStore(
  'user',
  {
    state: () => ({
      token: getToken(),
      id: '',
      name: '',
      nickName: '',
      avatar: '',
      roles: [],
      permissions: []
    }),
    actions: {
      // 登录
      login(userInfo) {
        const username = userInfo.username.trim()
        const password = userInfo.password
        return new Promise((resolve, reject) => {
          login(username, password).then(res => {
            setToken(res.access_token)
            this.token = res.access_token
            this.id = res.user_id
            // 从后端返回的角色信息，如果没有则默认为student
            const userRole = res.role || 'student'
            // 如果是admin角色，添加admin到角色列表
            this.roles = userRole === 'admin' ? ['admin'] : ['ROLE_DEFAULT']
            // 保存用户名、邮箱、用户ID和角色到本地存储
            localStorage.setItem('username', username)
            localStorage.setItem('email', username) // 由于后端使用email登录，所以将username作为email保存
            localStorage.setItem('user_id', res.user_id)
            localStorage.setItem('role', userRole)
            localStorage.setItem('roles', JSON.stringify(this.roles))
            useLockStore().unlockScreen()
            resolve()
          }).catch(error => {
            reject(error)
          })
        })
      },
      // 获取用户信息
      getInfo() {
        return new Promise((resolve, reject) => {
          getInfo().then(res => {
            const user = res
            let avatar = user.avatar || ""
            if (!isHttp(avatar)) {
              avatar = (isEmpty(avatar)) ? defAva : import.meta.env.VITE_APP_BASE_API + avatar
            }
            // 从本地存储获取角色信息，如果没有则设置默认角色
            const storedRoles = localStorage.getItem('roles')
            this.roles = storedRoles ? JSON.parse(storedRoles) : ['ROLE_DEFAULT']
            this.permissions = []
            this.id = user.id
            this.name = user.username
            this.nickName = user.username
            this.avatar = avatar
            resolve(res)
          }).catch(error => {
            reject(error)
          })
        })
      },
      // 退出系统
      logOut() {
        return new Promise((resolve, reject) => {
          logout().then(() => {
            this.token = ''
            this.roles = []
            this.permissions = []
            removeToken()
            // 清除本地存储的用户名、邮箱、用户ID、角色等信息
            localStorage.removeItem('username')
            localStorage.removeItem('email')
            localStorage.removeItem('phone')
            localStorage.removeItem('user_id')
            localStorage.removeItem('role')
            localStorage.removeItem('roles')
            resolve()
          }).catch(error => {
            reject(error)
          })
        })
      }
    }
  })

export default useUserStore
