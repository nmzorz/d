<template>
  <div class="chat-container">
    <!-- 左侧对话列表 -->
    <div class="chat-sidebar">
      <div class="sidebar-header">
        <h3>我的对话</h3>
        <el-button type="primary" @click="createNewChat" icon="Plus">新对话</el-button>
      </div>
      <div class="conversation-list">
        <div
          v-for="conversation in conversations"
          :key="conversation.id"
          class="conversation-item"
          :class="{ active: activeConversationId === conversation.id }"
          @click="selectConversation(conversation.id)"
        >
          <div class="conversation-title">{{ conversation.title }}</div>
          <div class="conversation-time">{{ formatTime(conversation.updated_at) }}</div>
        </div>
      </div>
    </div>

    <!-- 右侧聊天窗口 -->
    <div class="chat-main">
      <div v-if="!activeConversationId && !isNewChat" class="empty-state">
        <el-empty description="选择一个对话或创建新对话" />
      </div>
      <div v-else class="chat-window">
        <div class="chat-header">
          <h3>{{ activeConversation?.title || '新对话' }}</h3>
          <div class="header-actions">
            <el-button @click="editConversationTitle" icon="Edit" />
            <el-button @click="deleteConversation" icon="Delete" type="danger" />
          </div>
        </div>

        <div class="chat-messages" ref="chatMessagesRef">
          <div
            v-for="message in messages"
            :key="message.id"
            class="message"
            :class="message.role === 'user' ? 'user-message' : 'assistant-message'"
          >
            <div class="message-bubble">
              <div class="message-content" v-html="renderMarkdown(message.content)"></div>
              <div v-if="message.role === 'assistant' && message.source && message.source.length > 0" class="message-source">
                <div class="source-label">参考来源:</div>
                <div class="source-list">
                  <el-tag 
                    v-for="(source, index) in message.source"
                    :key="index" 
                    size="small" 
                    type="info" 
                    effect="plain" 
                    class="source-tag"
                    :class="{ 'source-link': getSourceUrl(source) }"
                    @click="getSourceUrl(source) ? openLink(getSourceUrl(source)) : null"
                  >
                    {{ source.source_id }}
                  </el-tag>
                </div>
              </div>
              <div v-if="message.role === 'assistant' && message.recommended_resources && message.recommended_resources.length > 0" class="message-resources">
                <div class="resource-label">推荐资源:</div>
                <div class="resource-list">
                  <el-tag 
                    v-for="(resource, index) in message.recommended_resources" 
                    :key="index" 
                    size="small" 
                    type="success" 
                    effect="plain" 
                    class="resource-tag"
                    :class="{ 'resource-link': resource.url || resource.link || resource.resource_url }"
                    @click="resource.url || resource.link || resource.resource_url ? openLink(resource.url || resource.link || resource.resource_url) : null"
                  >
                    {{ resource.title || resource.name || `资源 ${index + 1}` }}
                  </el-tag>
                </div>
              </div>
            </div>
            <div class="message-time">{{ formatTime(message.created_at) }}</div>
          </div>
          <div v-if="isTyping" class="message assistant-message">
            <div class="message-bubble typing">
              <div class="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        </div>

        <!-- 情绪标签 -->
        <div class="emotion-tags">
          <el-tag
            v-for="tag in emotionTags"
            :key="tag"
            effect="plain"
            @click="sendEmotionTag(tag)"
          >
            {{ tag }}
          </el-tag>
        </div>

        <div class="chat-input">
          <el-input
            v-model="inputMessage"
            type="textarea"
            placeholder="输入你的问题..."
            :rows="3"
            @keyup.enter.exact="sendMessage"
          />
          <div class="input-actions">
            <el-button @click="sendMessage" type="primary" icon="Send">发送</el-button>
            <el-button @click="triggerCrisisHelp" type="danger" icon="Warning">
              我需要紧急帮助
            </el-button>
          </div>
        </div>
      </div>
    </div>

    <!-- 编辑对话标题对话框 -->
    <el-dialog v-model="editTitleDialogVisible" title="编辑对话标题">
      <el-input v-model="editTitle" placeholder="输入对话标题" />
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="editTitleDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="saveConversationTitle">保存</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 安全提示对话框 -->
    <el-dialog v-model="safetyTipDialogVisible" title="安全提示" type="warning">
      <p>{{ safetyTipMessage }}</p>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="safetyTipDialogVisible = false">我知道了</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { ElMessage } from 'element-plus'
import * as insightApi from '@/api/insight'
import websocketService from '@/utils/websocket'
import useUserStore from '@/store/modules/user'

// 简单的 Markdown 渲染函数
const renderMarkdown = (text) => {
  if (!text) return ''
  
  // 替换标题
  text = text.replace(/^### (.*$)/gim, '<h3>$1</h3>')
  text = text.replace(/^## (.*$)/gim, '<h2>$1</h2>')
  text = text.replace(/^# (.*$)/gim, '<h1>$1</h1>')
  
  // 替换加粗
  text = text.replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
  
  // 替换斜体
  text = text.replace(/\*(.*?)\*/gim, '<em>$1</em>')
  
  // 替换链接
  text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/gim, '<a href="$2" target="_blank">$1</a>')
  
  // 替换列表
  text = text.replace(/^- (.*$)/gim, '<li>$1</li>')
  text = text.replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>')
  
  // 替换换行
  text = text.replace(/\n/gim, '<br>')
  
  return text
}

const userStore = useUserStore()
// 使用用户存储中的用户ID，如果没有则使用一个默认的UUID
// const userId = ref('7c8391d6-cd6b-4c16-af08-c5dd5809d244')
const userId = ref(userStore.id || '00000000-0000-0000-0000-000000000001')


const conversations = ref([])
const activeConversationId = ref(null)
const isNewChat = ref(false)
const messages = ref([])
const inputMessage = ref('')
const isTyping = ref(false)
const editTitleDialogVisible = ref(false)
const editTitle = ref('')
const safetyTipDialogVisible = ref(false)
const safetyTipMessage = ref('')
const chatMessagesRef = ref(null)

const emotionTags = ['焦虑', '压力', '孤独', '抑郁', '困惑', '愤怒', '悲伤', '恐惧']

const activeConversation = computed(() => {
  return conversations.value.find(c => c.id === activeConversationId.value)
})

// 格式化时间
const formatTime = (timeString) => {
  const date = new Date(timeString)
  return date.toLocaleString('zh-CN', {
    hour: '2-digit',
    minute: '2-digit'
  })
}

// 打开链接
const openLink = (url) => {
  if (url) {
    window.open(url, '_blank')
  }
}

// 获取参考来源的URL
const getSourceUrl = (source) => {
  if (source.metadata && source.metadata.source_url) {
    // 清理URL中的空格和反引号
    return source.metadata.source_url.trim().replace(/`/g, '')
  }
  return null
}

// 获取对话列表
const fetchConversations = async () => {
  try {
    console.log('获取对话列表，用户ID:', userId.value)
    const response = await insightApi.getConversations(userId.value)
    conversations.value = response
    console.log('获取对话列表成功:', conversations.value)
  } catch (error) {
    ElMessage.error('获取对话列表失败')
    console.error('获取对话列表失败:', error)
  }
}

// 获取消息列表
const fetchMessages = async (conversationId) => {
  try {
    const response = await insightApi.getMessages(conversationId)
    messages.value = response
    // 滚动到最底部
    setTimeout(() => {
      if (chatMessagesRef.value) {
        chatMessagesRef.value.scrollTop = chatMessagesRef.value.scrollHeight
      }
    }, 100)
  } catch (error) {
    ElMessage.error('获取消息失败')
    console.error(error)
  }
}

// 选择对话
const selectConversation = async (conversationId) => {
  activeConversationId.value = conversationId
  isNewChat.value = false
  await fetchMessages(conversationId)
  
  // 连接 WebSocket
  await websocketService.connect(userId.value, conversationId)
  setupWebSocketListeners()
}

// 创建新对话
const createNewChat = async () => {
  try {
    console.log('创建新对话，用户 ID:', userId.value)
    // 清空消息列表
    messages.value = []
    // 重置输入框
    inputMessage.value = ''
    // 重置打字状态
    isTyping.value = false
    // 设置新对话状态
    isNewChat.value = true
    
    // 断开旧的 WebSocket 连接
    websocketService.disconnect()
    
    // 注意：不主动连接 WebSocket，等待用户发送第一条消息时再连接
    // 这样避免提前创建空对话
    
    // 刷新对话列表
    await fetchConversations()
  } catch (error) {
    ElMessage.error('创建对话失败')
    console.error('创建对话失败:', error)
  }
}

// 发送消息
const sendMessage = async () => {
  console.log('发送消息 activeConversationId',activeConversationId.value)
  if (!inputMessage.value) return
  
  // 如果没有活动对话，先创建新对话
  if (!activeConversationId.value) {
    try {
      // 连接到创建新对话的 WebSocket
      await websocketService.connect(userId.value)
      setupWebSocketListeners()
      
      // 发送带标题的消息来创建对话
      const messageData = {
        message: inputMessage.value,
        title: inputMessage.value.substring(0, 30)
      }
      console.log('创建新对话并发送消息:', messageData)
      websocketService.send(messageData)
      
      // 添加到本地消息列表
      const tempMessage = {
        id: Date.now().toString(),
        role: 'user',
        content: inputMessage.value,
        created_at: new Date().toISOString()
      }
      messages.value.push(tempMessage)
      inputMessage.value = ''
      isTyping.value = true
      // 注意：不立即设置 activeConversationId，等待 WebSocket 返回 conversation_created 事件
    } catch (error) {
      ElMessage.error('发送消息失败')
      console.error(error)
    }
    return
  }
  
  try {
    // 先添加到本地消息列表
    const tempMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage.value,
      created_at: new Date().toISOString()
    }
    messages.value.push(tempMessage)
    
    // 发送 WebSocket 消息
    websocketService.send({ message: inputMessage.value })
    inputMessage.value = ''
    isTyping.value = true
  } catch (error) {
    ElMessage.error('发送消息失败')
    console.error(error)
  }
}

// 发送情绪标签
const sendEmotionTag = (tag) => {
  inputMessage.value = `我感到${tag}`
  sendMessage()
}

// 触发危机帮助
const triggerCrisisHelp = () => {
  safetyTipMessage.value = '我们注意到您可能处于危机状态。请记住，您并不孤独，有许多资源可以帮助您。\n\n如果您有紧急情况，请立即拨打以下热线：\n- 北京心理援助热线：010-82951332\n- 希望24热线：400-161-9995\n\n同时，我们的AI助手也会为您提供支持。'
  safetyTipDialogVisible.value = true
  
  // 发送危机消息
  inputMessage.value = '我感到崩溃，需要紧急帮助'
  sendMessage()
}

// 编辑对话标题
const editConversationTitle = () => {
  if (activeConversation.value) {
    editTitle.value = activeConversation.value.title
    editTitleDialogVisible.value = true
  }
}

// 保存对话标题
const saveConversationTitle = async () => {
  if (!editTitle.value || !activeConversationId.value) return
  
  try {
    await insightApi.updateConversationTitle(activeConversationId.value, {
      title: editTitle.value
    })
    const conversation = conversations.value.find(c => c.id === activeConversationId.value)
    if (conversation) {
      conversation.title = editTitle.value
    }
    editTitleDialogVisible.value = false
    ElMessage.success('标题更新成功')
  } catch (error) {
    ElMessage.error('更新标题失败')
    console.error(error)
  }
}

// 删除对话
const deleteConversation = async () => {
  if (!activeConversationId.value) return
  
  try {
    await insightApi.deleteConversation(activeConversationId.value)
    conversations.value = conversations.value.filter(c => c.id !== activeConversationId.value)
    activeConversationId.value = null
    messages.value = []
    ElMessage.success('对话删除成功')
  } catch (error) {
    ElMessage.error('删除对话失败')
    console.error(error)
  }
}

// 处理 WebSocket 消息
const handleWebSocketMessage = (data) => {
  console.log('WebSocket 消息:', data)
  switch (data.type) {
    case 'conversation_created':
      // 新对话创建成功，更新对话列表
      fetchConversations()
      activeConversationId.value = data.conversation_id
      isNewChat.value = false
      console.log('新对话 ID:', data.conversation_id)
      
      // 重要：重新连接 WebSocket，使用正确的 conversationId
      // 这样后续消息会发送到正确的对话中
      reconnectWebSocketWithConversation(activeConversationId.value)
      break
    case 'chunk':
      // 处理流式回复
      if (!messages.value.length || messages.value[messages.value.length - 1].role !== 'assistant') {
        // 开始新的回复
        messages.value.push({
          id: Date.now().toString(),
          role: 'assistant',
          content: data.content,
          created_at: new Date().toISOString()
        })
      } else {
        // 追加到现有回复
        messages.value[messages.value.length - 1].content += data.content
      }
      // 滚动到最底部
      setTimeout(() => {
        if (chatMessagesRef.value) {
          chatMessagesRef.value.scrollTop = chatMessagesRef.value.scrollHeight
        }
      }, 100)
      break
    case 'done':
      // 回复完成
      isTyping.value = false
      if (messages.value.length && messages.value[messages.value.length - 1].role === 'assistant') {
        // 更新完整回复信息
        messages.value[messages.value.length - 1].content = data.content || messages.value[messages.value.length - 1].content
        messages.value[messages.value.length - 1].source = data.source
        messages.value[messages.value.length - 1].recommended_resources = data.recommended_resources
      } else if (data.content) {
        // 如果没有现有消息且有内容，创建新消息
        messages.value.push({
          id: Date.now().toString(),
          role: 'assistant',
          content: data.content,
          source: data.source,
          recommended_resources: data.recommended_resources,
          created_at: new Date().toISOString()
        })
      }
      // 检查是否需要显示安全提示
      if (data.emotion_level === 'high') {
        safetyTipMessage.value = '我们注意到您的情绪状态可能需要特别关注。如果您感到困扰，请考虑寻求专业帮助。'
        safetyTipDialogVisible.value = true
      }
      // 滚动到最底部
      setTimeout(() => {
        if (chatMessagesRef.value) {
          chatMessagesRef.value.scrollTop = chatMessagesRef.value.scrollHeight
        }
      }, 100)
      break
    case 'error':
      isTyping.value = false
      ElMessage.error(data.content)
      break
  }
}

// 设置 WebSocket 监听器
const setupWebSocketListeners = () => {
  websocketService.onMessage(handleWebSocketMessage)
}

// 重新连接 WebSocket(用于对话创建后切换到正确的端点)
const reconnectWebSocketWithConversation = async (conversationId) => {
  try {
    // 断开当前连接
    websocketService.disconnect()
    // 使用 conversationId 重新连接
    await websocketService.connect(userId.value, conversationId)
    setupWebSocketListeners()
    console.log('已重新连接 WebSocket 到对话:', conversationId)
  } catch (error) {
    console.error('重新连接 WebSocket 失败:', error)
  }
}

// 组件挂载时获取对话列表
onMounted(async () => {
  // 确保userId使用最新的用户ID
  userId.value = userStore.id || '00000000-0000-0000-0000-000000000001'
  await fetchConversations()
  // 如果有对话，默认选择第一个
  if (conversations.value.length > 0) {
    await selectConversation(conversations.value[0].id)
  }
})

// 组件卸载时断开WebSocket连接
onUnmounted(() => {
  websocketService.disconnect()
})
</script>

<style scoped>
.chat-container {
  display: flex;
  height: calc(100vh - 50px);
  background-color: #f5f7fa;
  overflow: hidden;
}

.chat-sidebar {
  width: 300px;
  border-right: 1px solid #e4e7ed;
  background-color: #fff;
  display: flex;
  flex-direction: column;
}

.sidebar-header {
  padding: 20px;
  border-bottom: 1px solid #e4e7ed;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.conversation-list {
  flex: 1;
  overflow-y: auto;
}

.conversation-item {
  padding: 15px 20px;
  cursor: pointer;
  border-bottom: 1px solid #f0f0f0;
  transition: all 0.3s;
}

.conversation-item:hover {
  background-color: #f5f7fa;
}

.conversation-item.active {
  background-color: #ecf5ff;
  border-left: 3px solid #409eff;
}

.conversation-title {
  font-weight: 500;
  margin-bottom: 5px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.conversation-time {
  font-size: 12px;
  color: #909399;
}

.chat-main {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.empty-state {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f5f7fa;
}

.chat-window {
  flex: 1;
  display: flex;
  flex-direction: column;
  background-color: #fff;
  max-height: calc(100% - 80px);
  overflow: hidden;
}

.chat-header {
  padding: 15px 20px;
  border-bottom: 1px solid #e4e7ed;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #fafafa;
}

.header-actions {
  display: flex;
  gap: 10px;
}

.chat-messages {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
  background-color: #f5f7fa;
  min-height: 0;
}

.message {
  margin-bottom: 20px;
  display: flex;
  flex-direction: column;
  max-width: 70%;
}

.user-message {
  align-self: flex-end;
  margin-left: auto;
}

.assistant-message {
  align-self: flex-start;
}

.message-bubble {
  padding: 12px 16px;
  border-radius: 18px;
  position: relative;
  word-break: break-word;
}

.user-message .message-bubble {
  background-color: #409eff;
  color: #fff;
  border-bottom-right-radius: 4px;
}

.assistant-message .message-bubble {
  background-color: #fff;
  color: #303133;
  border: 1px solid #e4e7ed;
  border-bottom-left-radius: 4px;
}

.message-time {
  font-size: 12px;
  color: #909399;
  margin-top: 5px;
  align-self: flex-end;
}

.assistant-message .message-time {
  align-self: flex-start;
}

.message-source,
.message-resources {
  margin-top: 8px;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.source-label,
.resource-label {
  font-size: 12px;
  font-weight: 500;
  color: #606266;
  margin-bottom: 2px;
}

.source-list,
.resource-list {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  max-width: 100%;
}

.source-tag,
.resource-tag {
  max-width: 100%;
  word-break: break-all;
  white-space: normal;
  line-height: 1.4;
  padding: 2px 8px;
  transition: all 0.3s;
}

.source-link,
.resource-link {
  cursor: pointer;
  text-decoration: underline;
}

.source-link:hover,
.resource-link:hover {
  opacity: 0.8;
  transform: translateY(-1px);
}

.typing {
  display: flex;
  align-items: center;
}

.typing-indicator {
  display: flex;
  gap: 5px;
}

.typing-indicator span {
  width: 8px;
  height: 8px;
  background-color: #909399;
  border-radius: 50%;
  animation: typing 1.4s infinite ease-in-out both;
}

.typing-indicator span:nth-child(1) {
  animation-delay: -0.32s;
}

.typing-indicator span:nth-child(2) {
  animation-delay: -0.16s;
}

@keyframes typing {
  0%, 80%, 100% {
    transform: scale(0);
  }
  40% {
    transform: scale(1);
  }
}

.emotion-tags {
  padding: 10px 20px;
  border-top: 1px solid #e4e7ed;
  border-bottom: 1px solid #e4e7ed;
  background-color: #fafafa;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.chat-input {
  padding: 20px;
  border-top: 1px solid #e4e7ed;
  background-color: #fff;
}

.input-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 10px;
}
</style>