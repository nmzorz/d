<template>
  <div class="resources-container">
    <div class="resources-header">
      <h2>心理健康资源中心</h2>
      <el-input
        v-model="searchQuery"
        placeholder="搜索资源..."
        prefix-icon="Search"
        style="width: 300px"
      />
    </div>

    <div class="resources-filters">
      <el-select v-model="categoryFilter" placeholder="分类" style="width: 120px; margin-right: 10px">
        <el-option label="全部" value="" />
        <el-option label="文章" value="article" />
        <el-option label="练习" value="exercise" />
        <el-option label="热线" value="hotline" />
        <el-option label="外部资源" value="external" />
      </el-select>
      <el-select v-model="intentFilter" placeholder="意图类型" style="width: 120px; margin-right: 10px">
        <el-option label="全部" value="" />
        <el-option label="情绪宣泄" value="情绪宣泄" />
        <el-option label="知识问答" value="知识问答" />
        <el-option label="寻求建议" value="寻求建议" />
        <el-option label="闲聊" value="闲聊" />
      </el-select>
      <el-select v-model="emotionFilter" placeholder="情绪等级" style="width: 120px">
        <el-option label="全部" value="" />
        <el-option label="低" value="low" />
        <el-option label="中" value="medium" />
        <el-option label="高" value="high" />
      </el-select>
    </div>

    <div class="resources-list">
      <el-card
        v-for="resource in filteredResources"
        :key="resource.id"
        class="resource-card"
      >
        <template #header>
          <div class="card-header">
            <h3>{{ resource.title }}</h3>
            <el-tag :type="getTagType(resource.category)">{{ getCategoryName(resource.category) }}</el-tag>
          </div>
        </template>
        <div class="card-body">
          <p class="resource-summary">{{ resource.summary }}</p>
          <div v-if="resource.tags" class="resource-tags">
            <el-tag
              v-for="tag in resource.tags.split(',')"
              :key="tag"
              size="small"
              effect="plain"
            >
              {{ tag }}
            </el-tag>
          </div>
          <div class="resource-meta">
            <span v-if="resource.intent_type" class="meta-item">
              适用场景: {{ resource.intent_type }}
            </span>
            <span v-if="resource.min_emotion_level" class="meta-item">
              情绪等级: {{ getEmotionLevelName(resource.min_emotion_level) }}
            </span>
            <span v-if="resource.high_risk_only" class="meta-item high-risk">
              危机专用
            </span>
          </div>
          <div v-if="resource.url" class="resource-link">
            <el-button type="primary" size="small" @click="openResource(resource.url)">
              查看详情
            </el-button>
          </div>
        </div>
      </el-card>
    </div>

    <div v-if="filteredResources.length === 0" class="empty-state">
      <el-empty description="没有找到匹配的资源" />
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import * as insightApi from '@/api/insight'

const resources = ref([])
const searchQuery = ref('')
const categoryFilter = ref('')
const intentFilter = ref('')
const emotionFilter = ref('')

// 获取资源列表
const fetchResources = async () => {
  try {
    const response = await insightApi.getResources()
    resources.value = response.data
  } catch (error) {
    ElMessage.error('获取资源列表失败')
    console.error(error)
  }
}

// 过滤资源
const filteredResources = computed(() => {
  return resources.value.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
                        resource.summary.toLowerCase().includes(searchQuery.value.toLowerCase())
    const matchesCategory = !categoryFilter.value || resource.category === categoryFilter.value
    const matchesIntent = !intentFilter.value || resource.intent_type === intentFilter.value
    const matchesEmotion = !emotionFilter.value || resource.min_emotion_level === emotionFilter.value
    return matchesSearch && matchesCategory && matchesIntent && matchesEmotion
  })
})

// 获取分类名称
const getCategoryName = (category) => {
  const categoryMap = {
    article: '文章',
    exercise: '练习',
    hotline: '热线',
    external: '外部资源'
  }
  return categoryMap[category] || category
}

// 获取标签类型
const getTagType = (category) => {
  const typeMap = {
    article: 'info',
    exercise: 'success',
    hotline: 'warning',
    external: 'primary'
  }
  return typeMap[category] || 'default'
}

// 获取情绪等级名称
const getEmotionLevelName = (level) => {
  const levelMap = {
    low: '低',
    medium: '中',
    high: '高'
  }
  return levelMap[level] || level
}

// 打开资源链接
const openResource = (url) => {
  window.open(url, '_blank')
}

// 组件挂载时获取资源列表
onMounted(async () => {
  await fetchResources()
})
</script>

<style scoped>
.resources-container {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: 100vh;
}

.resources-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.resources-header h2 {
  margin: 0;
  color: #303133;
}

.resources-filters {
  margin-bottom: 20px;
  display: flex;
  align-items: center;
}

.resources-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 20px;
}

.resource-card {
  transition: all 0.3s;
}

.resource-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-header h3 {
  margin: 0;
  font-size: 16px;
  font-weight: 500;
}

.resource-summary {
  margin: 10px 0;
  color: #606266;
  line-height: 1.5;
}

.resource-tags {
  margin: 10px 0;
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}

.resource-meta {
  margin: 10px 0;
  font-size: 12px;
  color: #909399;
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.meta-item.high-risk {
  color: #f56c6c;
  font-weight: 500;
}

.resource-link {
  margin-top: 15px;
}

.empty-state {
  margin-top: 50px;
  text-align: center;
}
</style>