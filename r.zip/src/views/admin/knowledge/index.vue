<template>
  <div class="knowledge-container">
    <el-card shadow="never" class="knowledge-card">
      <template #header>
        <div class="card-header">
          <span>知识库管理</span>
          <el-button type="primary" @click="openAddDialog">添加知识</el-button>
        </div>
      </template>
      <el-table v-loading="loading" :data="knowledgeData" style="width: 100%">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="title" label="标题" />
        <el-table-column prop="category" label="分类" width="120" />
        <el-table-column prop="created_at" label="创建时间" width="180" />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="openEditDialog(scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="deleteKnowledge(scope.row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 添加/编辑对话框 -->
    <el-dialog v-model="dialogVisible" :title="dialogTitle">
      <el-form :model="form" :rules="rules" ref="formRef">
        <el-form-item label="标题" prop="title">
          <el-input v-model="form.title" placeholder="请输入标题" />
        </el-form-item>
        <el-form-item label="分类" prop="category">
          <el-select v-model="form.category" placeholder="请选择分类">
            <el-option label="焦虑" value="焦虑" />
            <el-option label="压力" value="压力" />
            <el-option label="孤独" value="孤独" />
            <el-option label="抑郁" value="抑郁" />
            <el-option label="人际关系" value="人际关系" />
          </el-select>
        </el-form-item>
        <el-form-item label="内容" prop="content">
          <el-input
            v-model="form.content"
            type="textarea"
            placeholder="请输入内容"
            :rows="5"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="saveKnowledge">保存</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'

const loading = ref(false)
const knowledgeData = ref([])
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)
const dialogVisible = ref(false)
const dialogTitle = ref('添加知识')
const formRef = ref(null)
const form = ref({
  id: '',
  title: '',
  category: '',
  content: ''
})
const rules = {
  title: [{ required: true, message: '请输入标题', trigger: 'blur' }],
  category: [{ required: true, message: '请选择分类', trigger: 'change' }],
  content: [{ required: true, message: '请输入内容', trigger: 'blur' }]
}

const fetchKnowledge = async () => {
  loading.value = true
  try {
    // 模拟数据
    knowledgeData.value = [
      {
        id: 1,
        title: '如何应对焦虑',
        category: '焦虑',
        content: '焦虑是一种常见的情绪反应，以下是一些应对方法：1. 深呼吸...',
        created_at: '2026-03-30 10:00:00'
      },
      {
        id: 2,
        title: '如何缓解压力',
        category: '压力',
        content: '压力过大时，可以尝试以下方法：1. 运动...',
        created_at: '2026-03-30 10:00:00'
      }
    ]
    total.value = 2
  } catch (error) {
    ElMessage.error('获取知识库失败')
    console.error(error)
  } finally {
    loading.value = false
  }
}

const handleSizeChange = (size) => {
  pageSize.value = size
  fetchKnowledge()
}

const handleCurrentChange = (current) => {
  currentPage.value = current
  fetchKnowledge()
}

const openAddDialog = () => {
  dialogTitle.value = '添加知识'
  form.value = {
    id: '',
    title: '',
    category: '',
    content: ''
  }
  dialogVisible.value = true
}

const openEditDialog = (row) => {
  dialogTitle.value = '编辑知识'
  form.value = { ...row }
  dialogVisible.value = true
}

const saveKnowledge = async () => {
  await formRef.value.validate((valid) => {
    if (valid) {
      // 模拟保存
      ElMessage.success(form.value.id ? '编辑成功' : '添加成功')
      dialogVisible.value = false
      fetchKnowledge()
    }
  })
}

const deleteKnowledge = (id) => {
  // 模拟删除
  ElMessage.success('删除成功')
  fetchKnowledge()
}

onMounted(() => {
  fetchKnowledge()
})
</script>

<style scoped>
.knowledge-container {
  padding: 20px;
}

.knowledge-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>