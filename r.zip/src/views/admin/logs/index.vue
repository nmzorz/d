<template>
  <div class="logs-container">
    <el-card shadow="never" class="logs-card">
      <template #header>
        <div class="card-header">
          <span>日志审计</span>
        </div>
      </template>
      <el-table v-loading="loading" :data="logsData" style="width: 100%">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="user_id" label="用户ID" width="180" />
        <el-table-column prop="action" label="操作" width="120" />
        <el-table-column prop="content" label="内容" />
        <el-table-column prop="created_at" label="时间" width="180" />
      </el-table>
      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'

const loading = ref(false)
const logsData = ref([])
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)

const fetchLogs = async () => {
  loading.value = true
  try {
    // 模拟数据
    logsData.value = [
      {
        id: 1,
        user_id: '00000000-0000-0000-0000-000000000001',
        action: '聊天',
        content: '用户发送了一条消息: 我感到焦虑',
        created_at: '2026-03-30 10:00:00'
      },
      {
        id: 2,
        user_id: '00000000-0000-0000-0000-000000000001',
        action: '聊天',
        content: 'AI回复: 我理解你的感受，焦虑是一种常见的情绪...',
        created_at: '2026-03-30 10:00:05'
      }
    ]
    total.value = 2
  } catch (error) {
    ElMessage.error('获取日志失败')
    console.error(error)
  } finally {
    loading.value = false
  }
}

const handleSizeChange = (size) => {
  pageSize.value = size
  fetchLogs()
}

const handleCurrentChange = (current) => {
  currentPage.value = current
  fetchLogs()
}

onMounted(() => {
  fetchLogs()
})
</script>

<style scoped>
.logs-container {
  padding: 20px;
}

.logs-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style>