<template>
  <div class="app-container home">
    <el-row :gutter="20">
      <el-col :sm="24" :lg="12" style="padding-left: 20px">
        <h2>心理健康智能助手</h2>
        <p>
          心理健康智能助手是一个专注于大学生心理健康的智能对话系统，旨在为学生提供专业、共情、安全的心理支持。
          系统基于先进的人工智能技术，结合专业的心理健康知识库，为用户提供个性化的心理支持和建议。
        </p>
        <p>
          <b>系统功能:</b>
        </p>
        <ul>
          <li>智能心理对话：通过AI技术提供专业的心理支持</li>
          <li>危机检测与干预：识别并应对危机情况</li>
          <li>心理健康资源中心：提供丰富的心理健康资源</li>
          <li>后台管理：日志审计和知识库管理</li>
        </ul>
        <p>
          <el-button
            type="primary"
            icon="ChatDotRound"
            plain
            @click="goToChat"
            >开始对话</el-button
          >
          <el-button
            icon="Document"
            plain
            @click="goToResources"
            >资源中心</el-button
          >
        </p>
      </el-col>

      <el-col :sm="24" :lg="12" style="padding-left: 50px">
        <el-row>
          <el-col :span="12">
            <h2>系统优势</h2>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <h4>专业支持</h4>
            <p>基于专业的心理健康知识库，提供科学、准确的心理支持</p>
          </el-col>
          <el-col :span="6">
            <h4>共情理解</h4>
            <p>通过先进的AI技术，理解用户情绪，提供共情的回应</p>
          </el-col>
          <el-col :span="6">
            <h4>安全保障</h4>
            <p>严格的内容安全检查，确保用户获得安全、积极的支持</p>
          </el-col>
          <el-col :span="6">
            <h4>资源丰富</h4>
            <p>提供多样化的心理健康资源，满足不同用户的需求</p>
          </el-col>
        </el-row>
      </el-col>
    </el-row>
    <el-divider />
    <el-row :gutter="20">
      <el-col :xs="24" :sm="24" :md="12" :lg="8">
        <el-card class="info-card">
          <template v-slot:header>
            <div class="clearfix">
              <span>使用指南</span>
            </div>
          </template>
          <div class="body">
            <p>
              <i class="el-icon-arrow-right"></i> 点击「开始对话」进入智能聊天界面
            </p>
            <p>
              <i class="el-icon-arrow-right"></i> 在聊天界面中输入你的问题或情绪
            </p>
            <p>
              <i class="el-icon-arrow-right"></i> 系统会根据你的输入提供专业的心理支持
            </p>
            <p>
              <i class="el-icon-arrow-right"></i> 点击「资源中心」浏览心理健康相关资源
            </p>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="8">
        <el-card class="info-card">
          <template v-slot:header>
            <div class="clearfix">
              <span>危机干预</span>
            </div>
          </template>
          <div class="body">
            <p>
              <i class="el-icon-warning"></i> 如果你正处于危机状态，请立即拨打以下热线：
            </p>
            <p>
              <strong>北京心理援助热线：</strong> 010-82951332
            </p>
            <p>
              <strong>希望24热线：</strong> 400-161-9995
            </p>
            <p>
              <i class="el-icon-info"></i> 系统会自动识别危机信号，并提供相应的支持和资源
            </p>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="8">
        <el-card class="info-card">
          <template v-slot:header>
            <div class="clearfix">
              <span>关于系统</span>
            </div>
          </template>
          <div class="body">
            <p>
              <i class="el-icon-info"></i> 心理健康智能助手是一个基于人工智能技术的心理支持系统
            </p>
            <p>
              <i class="el-icon-info"></i> 系统旨在为大学生提供专业、共情、安全的心理支持
            </p>
            <p>
              <i class="el-icon-info"></i> 如有任何问题或建议，请联系系统管理员
            </p>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

const goToChat = () => {
  router.push('/insight/chat')
}

const goToResources = () => {
  router.push('/insight/resources')
}
</script>

<style scoped>
.home {
  padding: 20px;
}

.info-card {
  margin-bottom: 20px;
}

.body {
  line-height: 1.8;
}

.el-button {
  margin-right: 10px;
  margin-top: 10px;
}

ul {
  list-style: disc;
  padding-left: 20px;
  margin-bottom: 20px;
}

li {
  margin-bottom: 10px;
}
</style>