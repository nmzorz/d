<template>
   <el-form ref="userRef" :model="form" :rules="rules" label-width="80px">
      <el-form-item label="用户名" prop="username">
         <el-input v-model="form.username" maxlength="20" disabled />
      </el-form-item>
      <el-form-item label="用户昵称" prop="nickName">
         <el-input v-model="form.nickName" maxlength="30" />
      </el-form-item>
      <el-form-item label="手机号码" prop="phone">
         <el-input v-model="form.phone" maxlength="11" />
      </el-form-item>
      <el-form-item label="邮箱" prop="email">
         <el-input v-model="form.email" maxlength="50" />
      </el-form-item>
      <el-form-item>
      <el-button type="primary" @click="submit">保存</el-button>
      <el-button type="danger" @click="close">关闭</el-button>
      </el-form-item>
   </el-form>
</template>

<script setup>
import { ref, watch, getCurrentInstance } from 'vue'
import { ElMessage } from 'element-plus'
import * as insightApi from '@/api/insight'

const props = defineProps({
  user: {
    type: Object
  }
})

const { proxy } = getCurrentInstance()

const form = ref({})
const rules = ref({
  username: [{ required: true, message: "用户名不能为空", trigger: "blur" }],
  nickName: [{ required: true, message: "用户昵称不能为空", trigger: "blur" }],
  email: [{ type: "email", message: "请输入正确的邮箱地址", trigger: ["blur", "change"] }],
  phone: [{ pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/, message: "请输入正确的手机号码", trigger: "blur" }],
})

/** 提交按钮 */
function submit() {
  proxy.$refs.userRef.validate(valid => {
    if (valid) {
      // 准备更新数据
      const updateData = {
        username: form.value.username,
        phone: form.value.phone,
        email: form.value.email
      }
      // 调用后端API更新用户信息
      insightApi.updateUser(props.user.id, updateData).then(() => {
        ElMessage.success("修改成功")
        // 更新父组件中的用户信息
        if (props.user) {
          props.user.phone = form.value.phone
          props.user.email = form.value.email
        }
        // 更新本地存储的用户信息
        localStorage.setItem('email', form.value.email)
        localStorage.setItem('phone', form.value.phone)
      }).catch(() => {
        ElMessage.error("修改失败")
      })
    }
  })
}

/** 关闭按钮 */
function close() {
  proxy.$tab.closePage()
}

// 回显当前登录用户信息
watch(() => props.user, user => {
  if (user) {
    form.value = {
      username: user.name || user.username,
      nickName: user.nickName || user.username,
      phone: user.phone || '',
      email: user.email || ''
    }
  }
},{ immediate: true })
</script>
