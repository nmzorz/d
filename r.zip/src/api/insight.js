import request from '@/utils/request'

// 用户相关API
export function register(data) {
  return request({
    url: '/users/register',
    method: 'post',
    data
  })
}

export function login(data) {
  return request({
    url: '/users/login',
    method: 'post',
    data
  })
}

export function getCurrentUser() {
  return request({
    url: '/users/me',
    method: 'get'
  })
}

export function updateUser(userId, data) {
  return request({
    url: `/users/${userId}`,
    method: 'put',
    data
  })
}

export function updateUserPassword(userId, data) {
  return request({
    url: `/users/${userId}/password`,
    method: 'put',
    data
  })
}

export function logout() {
  return request({
    url: '/users/logout',
    method: 'post'
  })
}

// 对话相关API
export function getConversations(userId) {
  return request({
    url: `/conversations/user/${userId}`,
    method: 'get'
  })
}

export function getConversationDetail(conversationId) {
  return request({
    url: `/conversations/${conversationId}`,
    method: 'get'
  })
}

export function updateConversationTitle(conversationId, data) {
  return request({
    url: `/conversations/${conversationId}`,
    method: 'put',
    data
  })
}

export function deleteConversation(conversationId) {
  return request({
    url: `/conversations/${conversationId}`,
    method: 'delete'
  })
}

export function getMessages(conversationId) {
  return request({
    url: `/conversations/${conversationId}/messages`,
    method: 'get'
  })
}

export function chatInConversation(conversationId, data) {
  return request({
    url: `/conversations/${conversationId}/chat`,
    method: 'post',
    data
  })
}

export function createConversationAndChat(userId, data) {
  return request({
    url: `/conversations/user/${userId}/chat`,
    method: 'post',
    data
  })
}

// 资源相关API
export function getResources(params) {
  return request({
    url: '/resources/',
    method: 'get',
    params
  })
}

// 知识库相关API
export function queryKnowledgeBase(data) {
  return request({
    url: '/knowledge-base/query',
    method: 'post',
    data
  })
}

// 高危识别相关API
export function getHighRiskCases() {
  return request({
    url: '/high-risk/cases',
    method: 'get'
  })
}

// 意图分析相关API
export function getIntentAnalysisStats() {
  return request({
    url: '/intent-analysis/stats/summary',
    method: 'get'
  })
}