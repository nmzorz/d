import request from '@/utils/request'

// 登录方法
export function login(username, password) {
  const data = {
    email: username, // 后端只支持email登录，所以将username作为email传入
    password
  }
  return request({
    url: '/users/login',
    headers: {
      isToken: false,
      repeatSubmit: false
    },
    method: 'post',
    data: data
  })
}

// 注册方法
export function register(data) {
  return request({
    url: '/users/register',
    headers: {
      isToken: false
    },
    method: 'post',
    data: data
  })
}

// 获取用户详细信息
export function getInfo() {
  // 由于后端没有/users/me端点，返回模拟数据
  return new Promise((resolve) => {
    const userInfo = {
      id: localStorage.getItem('user_id') || '1',
      username: localStorage.getItem('username') || 'admin',
      email: localStorage.getItem('email') || 'admin@example.com',
      phone: localStorage.getItem('phone') || '',
      avatar: ''
    }
    resolve(userInfo)
  })
}

// 退出方法
export function logout() {
  // 由于后端没有/users/logout端点，直接返回成功
  return new Promise((resolve) => {
    resolve({ message: 'Logout successful' })
  })
}