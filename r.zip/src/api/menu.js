import request from '@/utils/request'

// 获取路由
export const getRouters = () => {
  // 由于后端没有提供getRouters接口，返回空数组
  return new Promise((resolve) => {
    resolve([])
  })
}