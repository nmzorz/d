package com.xyh.behavioral.template;

public class AutoCookMachine extends CookTemplate{

    @Override
    public void addFood() {
        System.out.println("放了三个小白菜");
    }

    @Override
    public void addSalt() {
        System.out.println("放了三勺盐");
    }
}
