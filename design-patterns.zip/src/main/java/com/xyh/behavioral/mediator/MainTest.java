package com.xyh.behavioral.mediator;


/**
 * 中介者：
 *中介者模式(Mediator Pattern)：用一个中介对象来封装一系列的对象交互，中介者使各对象不需要显式地相互引用，
 * 减少对象间混乱的依赖关系，从而使其耦合松散，而且可以独立地改变它们之间的交互。对象行为型模式。
 *
 * Mediator: 抽象中介者
 * ConcreteMediator: 具体中介者
 * Colleague: 抽象同事类
 * ConcreteColleague: 具体同事类
 *
 * 什么场景用到？
 * SpringMVC 的 DispatcherServlet是一个中介者，他会提取Controller、Model、View来进行调用。
 * 而无需controller直接调用view之类的渲染方法
 * 分布式系统中的网关
 * 迪米特法则的一个典型应用
 *
 */
public class MainTest {

    public static void main(String[] args) {
        HU8778 hu8778 = new HU8778();
        SC8633 sc8633 = new SC8633();

        ControlTower tower = new ControlTower();
        hu8778.setControlTower(tower);
        sc8633.setControlTower(tower);

        hu8778.fly();
        hu8778.success();
        sc8633.fly();


    }
}
