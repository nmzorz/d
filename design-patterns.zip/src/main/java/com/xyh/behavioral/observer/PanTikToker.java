package com.xyh.behavioral.observer;

import java.util.ArrayList;
import java.util.List;

/**
 * 主播
 * 双向观察
 */
public class PanTikToker extends AbstractTikToker{

    //1、观察者的核心1
    List<AbstractFans> fansList = new ArrayList<>();

    void startSell() {
        System.out.println("潘子开始卖货...");
        notifyFans("我开始卖⑨了，只要666");
    }
    void endSell() {
        System.out.println("结束卖货...");
        notifyFans("已经卖完了，记得五星好评...");
    }


    @Override
    void addFans(AbstractFans fans) {
        fansList.add(fans);
    }

    //通知所有观察者
    @Override
    void notifyFans(String msg) {
        //1、所有粉丝拿来通知
        for (AbstractFans fans : fansList) {
            fans.acceptMsg(msg);
        }
    }
}
