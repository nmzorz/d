package com.xyh.behavioral.strategy;

/**
 * 游戏策略
 */
public interface GameStrategy {

    //战斗策略
    void warStrategy();

}
