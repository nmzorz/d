package com.xyh.behavioral.chain;

/**
 *         //1、链条的引用点
 *         //2、下一个继续
 *         //3、构造链条
 *
 *   回旋责任链
 *   Filter：1 -- 2 -- 3 -- 本人 -- 3 -- 2 -- 1
 *
 */
public class MainTest {

    public static void main(String[] args) {

        Teacher luoXiang = new Teacher("LuoXiang");

        Teacher zhangSan = new Teacher("ZhangSan");

        Teacher liSi = new Teacher("LiSi");

        luoXiang.setNext(zhangSan);
        zhangSan.setNext(liSi);

        luoXiang.handleRequest();


    }
}
