package com.xyh.behavioral.chain.ext;

public class My {

    void hello(){

        System.out.println("调用my.hello()");
    }
}
