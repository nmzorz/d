package com.xyh.structural.flyweight;


/**
 *享元模式(Flyweight Pattern)，运用共享技术有效地支持大量细粒度对象的复用。
 * 系统只使用少量的对象，而这些对象都很相似，状态变化很小，可以实现对象的多次复用。对象结构型
 *在享元模式中可以共享的相同内容称为内部状态(IntrinsicState)，
 * 而那些需要外部环境来设置的不能共享的内容称为外部状态(Extrinsic State)，
 * 由于区分了内部状态和外部状态，因此可以通过设置不同的外部状态使得相同的对象可以具有一些不同的特征，而相同的内部状态是可以共享的。
 *
 * 在享元模式中通常会出现工厂模式，需要创建一个享元工厂来负责维护一个享元池(Flyweight Pool)用于存储具有相同内部状态的享元对象。
 *
 * 享元模式包含如下角色：
 * Flyweight: 抽象享元类  Connection
 * ConcreteFlyweight: 具体享元类  ConnectionImpl（user,pwd,url）
 * UnsharedConcreteFlyweight: 非共享具体享元类ConnectionImpl（state）
 * FlyweightFactory: 享元工厂类；简单工厂，产品就一个Connection
 * （数据库连接user,pwd,url一样，但是state不一样）
 *
 * 什么场景用到？
 * 典型的代表：数据库连接池
 * 所有的池化技术
 * 享元和原型模式有什么区别？享元是预先准备好的对象进行复用，原型没法确定预先有哪些
 */
public class MainTest {

    public static void main(String[] args) {

        AbstractWaitress waitress = ZuDao.getWaitress("");
        waitress.service();
        System.out.println(waitress);

        AbstractWaitress waitress1 = ZuDao.getWaitress("");
        waitress1.service();
        waitress1.end();//结束之后即可点到

        AbstractWaitress waitress2 = ZuDao.getWaitress("");//只有两个服务员，点不到
        System.out.println(waitress2);
    }







}
