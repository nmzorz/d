package com.xyh.structural.flyweight;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 足道店：这相当于享元工厂
 *      店里面很多服务员。
 *
 * 享元和原型
 * 1、享元返回的是这个本人。
 * 2、原型返回的是克隆人。
 *
 */
public class ZuDao {

    private static Map<String, AbstractWaitress> pool = new HashMap<>();
    //享元，池子中有对象
    static {
        Waitress waitress =
                new Waitress("1111","张三",18);

        Waitress waitress2 =
                new Waitress("9527","李四",20);


        pool.put(waitress.id,waitress);
        pool.put(waitress2.id,waitress2);
    }

    public void addWaitress(AbstractWaitress waitressFlyweight){
        pool.put(UUID.randomUUID().toString(),waitressFlyweight);
    }

    /**
     * 获取服务员，可指定id，没有的话选一个可服务的
     */
    public static AbstractWaitress getWaitress(String id){
        AbstractWaitress flyweight = pool.get(id);
        if(flyweight == null){
            for (AbstractWaitress value : pool.values()) {
                //当前共享对象能否是否
                if(value.isCanService()){
                    return value;
                }
            };
            return null;
        }
        return flyweight;
    }

}
