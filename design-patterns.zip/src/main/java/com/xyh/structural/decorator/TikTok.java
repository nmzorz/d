package com.xyh.structural.decorator;


/**
 * 抽象构建
 */
public  interface TikTok {
   void tiktok();
}
