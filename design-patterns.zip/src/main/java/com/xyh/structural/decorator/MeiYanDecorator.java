package com.xyh.structural.decorator;

/**
 * 美颜装饰器
 * 装饰器只关系增强这个类的方法
 */
public class MeiYanDecorator implements TiktokDecorator{
    private final TikTok tikTok;

    public MeiYanDecorator(TikTok tikTok) {
        this.tikTok = tikTok;
    }

    @Override
    public void tiktok() {
        enable();
        tikTok.tiktok();
    }

    @Override
    public void enable() {
        System.out.println("开启美颜");
    }
}
