package com.xyh.structural.decorator;

public class MyTikTok implements TikTok {
    @Override
    public void tiktok() {
        System.out.println("我在抖音开直播");
    }
}
