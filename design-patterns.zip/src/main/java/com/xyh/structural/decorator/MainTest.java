package com.xyh.structural.decorator;


/**
 * 装饰器模式（Decorator/Wrapper（包装） Pattern）
 *
 * 向一个现有的对象添加新的功能，同时又不改变其结构。属于对象结构型模式。
 * 创建了一个装饰类，用来包装原有的类，并在保持类方法签名完整性的前提下，提供了额外的功能。
 *
 * 核心：想要不改变原来接口方法的情况下扩展新功能，或者增强方法.....
 *
 * 抽象构件（Component）角色：
 * 定义一个抽象接口以规范准备接收附加责任的对象。
 * 具体构件（ConcreteComponent）角色：
 * 实现抽象构件，通过装饰角色为其添加一些职责。
 * 抽象装饰（Decorator）角色：
 * 继承抽象构件，并包含具体构件的实例，可以通过其子类扩展具体构件的功能。
 * 具体装饰（ConcreteDecorator）角色：
 * 实现抽象装饰的相关方法，并给具体构件对象添加附加的责任。
 *
 * 适配器是连接两个类，可以增强一个类，装饰器是增强一个类
 *
 * 场景使用
 *  SpringSession中如何进行session与redis关联？HttpRequestWrapper
 *  MyBatisPlus提取了QueryWrapper，这是什么？
 *  Spring中的BeanWrapper是做什么？包装了Bean。bean的功能增强？
 *  Spring Webflux中的 WebHandlerDecorator？
 *  已存的类，每一天在某个功能使用的时候发现不够，就可以装饰器。
 */
public class MainTest {

    public static void main(String[] args) {
        //被装饰对象
        TikTok tikTok = new MyTikTok();
//        tikTok.tiktok();

        TiktokDecorator decorator = new MeiYanDecorator(tikTok);
        decorator.tiktok();
    }


}
