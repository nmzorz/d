package com.xyh.structural.proxy.dynamic;

public interface Sell {
    void sell();
}
