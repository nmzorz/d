package com.xyh.structural.proxy.dynamic;


/**
 * 抽象构建
 */
public  interface TikTok {
   void tiktok();
}
