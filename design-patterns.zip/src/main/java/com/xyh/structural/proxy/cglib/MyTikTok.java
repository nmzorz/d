package com.xyh.structural.proxy.cglib;

public class MyTikTok{
    public void tiktok() {
        System.out.println("我在抖音开直播");
    }

}
