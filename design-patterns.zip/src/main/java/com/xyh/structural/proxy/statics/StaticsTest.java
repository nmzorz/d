package com.xyh.structural.proxy.statics;

public class StaticsTest {
    public static void main(String[] args) {

        TikTok tikTok = new MyTikTokProxy(new MyTikTok());
        tikTok.tiktok();
    }

}
