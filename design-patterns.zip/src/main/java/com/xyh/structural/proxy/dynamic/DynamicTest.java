package com.xyh.structural.proxy.dynamic;

import java.util.Arrays;

public class DynamicTest {
    public static void main(String[] args) {
        TikTok tikTok = JdkProxy.getProxy(new MyTikTok());
        tikTok.tiktok();

        ((Sell)tikTok).sell();
//        ((MyTikTok)tikTok).me(); 不能代理对象本类自己的方法

        System.out.println(Arrays.toString(tikTok.getClass().getInterfaces()));
    }

}
