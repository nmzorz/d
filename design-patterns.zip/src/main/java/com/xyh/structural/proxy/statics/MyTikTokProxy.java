package com.xyh.structural.proxy.statics;

public class MyTikTokProxy implements TikTok{
    private final TikTok tikTok;

    public MyTikTokProxy(TikTok tikTok) {
        this.tikTok = tikTok;
    }

    @Override
    public void tiktok() {
        System.out.println("进行增强");
        tikTok.tiktok();
    }
}
