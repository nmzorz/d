package com.xyh.structural.proxy.cglib;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;

/**
 * 使用cglib帮我们创建出代理对象
 */
public class CglibProxy {
    public static <T> T createProxy(T t) {
//        1.创建一个增强器
        Enhancer enhancer = new Enhancer();
//        2、设置要增强哪个类的功能。增强器为这个类动态创建一个子类
        enhancer.setSuperclass(t.getClass());
        //3、设置回调
        enhancer.setCallback((MethodInterceptor) (obj, method, args, proxy) -> {
            System.out.println("cglib拦截");
            Object invokeSuper = proxy.invokeSuper(obj, args);//目标方法执行
            return invokeSuper;
        });
        return (T)enhancer.create();
    }
}
