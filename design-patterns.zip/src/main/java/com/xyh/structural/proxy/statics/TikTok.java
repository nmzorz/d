package com.xyh.structural.proxy.statics;


/**
 * 抽象构建
 */
public  interface TikTok {
   void tiktok();
}
