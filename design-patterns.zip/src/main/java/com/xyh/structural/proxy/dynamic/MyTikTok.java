package com.xyh.structural.proxy.dynamic;

public class MyTikTok implements TikTok,Sell {
    @Override
    public void tiktok() {
        System.out.println("我在抖音开直播");
    }

    @Override
    public void sell() {
        System.out.println("卖货");
    }

    public void me(){
        System.out.println("自己的方法");
    }
}
