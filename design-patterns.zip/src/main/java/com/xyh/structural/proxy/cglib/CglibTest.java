package com.xyh.structural.proxy.cglib;

public class CglibTest {
    public static void main(String[] args) {
        MyTikTok tikTok = new MyTikTok();
        MyTikTok proxy = CglibProxy.createProxy(tikTok);
        proxy.tiktok();
    }
}
