package com.xyh.structural.bridge;

public class StudentSale extends AbstractSale {
    public StudentSale(String type, Integer price) {
        super(type, price);
    }
}
