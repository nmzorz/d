package com.xyh.structural.adapter;

/**
 * 继承的方式：类结构模型，适配转换到了翻译器的功能上
 */
public class JPMoviePlayerClazzAdapter extends Zh_JPTranslator implements Player{
    private final Player target;//被适配对象

    public JPMoviePlayerClazzAdapter(Player target) {
        this.target = target;
    }

    @Override
    public String play() {
        String play = target.play();
        String translate = translate(play);
        System.out.println("日文：" + translate);
        return play;
    }
}
