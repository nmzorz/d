package com.xyh.structural.adapter;

/**
 * 组合的方式：对象结构模型，适配转换到了翻译器的功能上
 */
public class JPMoviePlayerObjAdapter implements Player{
    private final Translator translator = new Zh_JPTranslator();
    private final Player target;//被适配对象

    public JPMoviePlayerObjAdapter(Player target) {
        this.target = target;
    }

    @Override
    public String play() {
        String play = target.play();
        String translate = translator.translate(play);
        System.out.println("日文：" + translate);
        return play;
    }
}
