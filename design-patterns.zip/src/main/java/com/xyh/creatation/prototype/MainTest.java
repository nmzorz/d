package com.xyh.creatation.prototype;

/**
 * 原型模式：是用于创建重复的对象，同时又能保证性能。
 * 缓存；查过的保存。
 *     如果再查相同的记录，拿到原来的原型对象
 *
 */
public class MainTest {

    public static void main(String[] args) throws Exception {
//        Mybatis mybatis = new Mybatis();
        MybatisPlus mybatis = new MybatisPlus();

        //十分危险
        //得到的是克隆体
        User zhangsan1 = mybatis.getUser("zhangsan");
        System.out.println("1==>"+zhangsan1);
        zhangsan1.setUsername("李四2.。。");
        System.out.println("zhangsan1自己改了："+zhangsan1);


        //得到的是克隆体
        User zhangsan2 = mybatis.getUser("zhangsan");

        System.out.println("2-->"+zhangsan2);

        //得到的是克隆体
        User zhangsan3 = mybatis.getUser("zhangsan");
        System.out.println("3-->"+zhangsan3);

        //得到的是克隆体
        User zhangsan4 = mybatis.getUser("zhangsan");
        System.out.println("4-->"+zhangsan4);

        System.out.println(zhangsan1 == zhangsan3);

    }
}
