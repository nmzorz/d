package com.xyh.creatation.prototype;

import java.util.HashMap;
import java.util.Map;

public class Mybatis {

    //缓存user.序列化和反序列化-深克隆
    private Map<String,User> userCache = new HashMap<>();

    /**
     * 从数据库查数据
     * @return
     */
    public User getUser(String username) throws Exception {
        User user = null;
        //缓存中没有
        if(!userCache.containsKey(username)){
            //查询数据库
            user = getUserFromDb(username);
        }else {
            //从缓存中直接拿，脏缓存问题
            user = userCache.get(username);
            System.out.println("从缓存中拿到的是："+user);
        }

        return user;
    }

    private User getUserFromDb(String username) throws Exception{
        System.out.println("从数据库查到："+username);
        User user = new User();
        user.setUsername(username);
        user.setAge(18);
        userCache.put(username, user);
        return user;
    }


}
