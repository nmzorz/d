package com.xyh.creatation.factory.abstractfactory;
/**
 * 具体产品
 */
public class N95Mask extends AbstractMask{
    public N95Mask() {
        price = 20;
    }

    @Override
    public void protectedMe() {
        System.out.println("n95");
    }
}
