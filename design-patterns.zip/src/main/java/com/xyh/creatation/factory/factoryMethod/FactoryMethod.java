package com.xyh.creatation.factory.factoryMethod;

/**
 * 四个角色
 * Product:抽象产品
 * ConcreteProduct:具体产品
 * Factory:抽象工厂
 * ConcreteFactory:具体工厂
 */
public class FactoryMethod {
    public static void main(String[] args) {
        AbstractCarFactory carFactory = new VanFactory();
        AbstractCar abstractCar = carFactory.newCar();
        abstractCar.run();

        carFactory = new MiniFactory();
        abstractCar = carFactory.newCar();
        abstractCar.run();
    }
}
