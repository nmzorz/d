package com.xyh.creatation.factory.factoryMethod;

public class MiniFactory extends AbstractCarFactory{

    @Override
    public AbstractCar newCar() {
        return new MiniCar();
    }
}
