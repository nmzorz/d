package com.xyh.creatation.factory.factoryMethod;

public class MiniCar extends AbstractCar {
    public MiniCar() {
        engine = "Mini发动机";
    }

    @Override
    public void run() {
        System.out.println(engine);
    }
}
