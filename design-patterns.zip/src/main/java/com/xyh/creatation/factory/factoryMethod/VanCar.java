package com.xyh.creatation.factory.factoryMethod;

public class VanCar extends AbstractCar {
    public VanCar() {
        engine = "货车发动机";
    }

    @Override
    public void run() {
        System.out.println(engine);
    }
}
