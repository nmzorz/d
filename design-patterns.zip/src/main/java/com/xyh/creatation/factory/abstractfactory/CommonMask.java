package com.xyh.creatation.factory.abstractfactory;
/**
 * 具体产品
 */
public class CommonMask extends AbstractMask{
    public CommonMask() {
        price = 10;
    }

    @Override
    public void protectedMe() {
        System.out.println("普通口罩");
    }
}
