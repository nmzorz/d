package com.xyh.creatation.factory.abstractfactory;

public interface Factory {
    AbstractCar newCar();
    AbstractMask newMask();
}
