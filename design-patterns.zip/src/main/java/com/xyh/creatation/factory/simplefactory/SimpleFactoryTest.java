package com.xyh.creatation.factory.simplefactory;

public class SimpleFactoryTest {
    public static void main(String[] args) {
        SimpleFactory factory = new SimpleFactory();
        AbstractCar van = factory.newCar("van");
        AbstractCar mini = factory.newCar("mini");
        AbstractCar zzz = factory.newCar("zzz");

        System.out.println(van);
        System.out.println(mini);
        System.out.println(zzz);

        van.run();
        mini.run();
    }
}
