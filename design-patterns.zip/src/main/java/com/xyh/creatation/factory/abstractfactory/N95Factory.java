package com.xyh.creatation.factory.abstractfactory;

public class N95Factory extends AbstractMaskFactory {
    @Override
    public AbstractMask newMask() {
        return new N95Mask();
    }
}
