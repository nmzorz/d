package com.xyh.creatation.factory.abstractfactory;

public class VanFactory extends AbstractCarFactory {

    @Override
    public AbstractCar newCar() {
        return new VanCar();
    }
}
