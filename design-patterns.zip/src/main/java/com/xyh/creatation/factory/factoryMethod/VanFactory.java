package com.xyh.creatation.factory.factoryMethod;

public class VanFactory extends AbstractCarFactory{

    @Override
    public AbstractCar newCar() {
        return new VanCar();
    }
}
