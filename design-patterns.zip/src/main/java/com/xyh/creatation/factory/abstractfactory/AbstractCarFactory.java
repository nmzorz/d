package com.xyh.creatation.factory.abstractfactory;

/**
 * 汽车抽象工厂的层级
 */
public abstract class AbstractCarFactory implements Factory{
    @Override
    public abstract AbstractCar newCar();

    @Override
    public AbstractMask newMask() {
        return null;
    }
}
