package com.xyh.creatation.factory.abstractfactory;

/**
 * 四个角色
 * Product:抽象产品
 * ConcreteProduct:具体产品
 * Factory:抽象工厂
 * ConcreteFactory:具体工厂
 */
public class AbstractFactoryTest {
    public static void main(String[] args) {
        Factory carFactory = new VanFactory();
        AbstractCar abstractCar = carFactory.newCar();
        abstractCar.run();

        carFactory = new MiniFactory();
        abstractCar = carFactory.newCar();
        abstractCar.run();

        Factory maskFactory = new N95Factory();
        AbstractMask n95Mask = maskFactory.newMask();
        n95Mask.protectedMe();

        maskFactory = new CommonFactory();
        AbstractMask commonMask = maskFactory.newMask();
        commonMask.protectedMe();
    }














}
