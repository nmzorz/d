package com.xyh.creatation.factory.abstractfactory;

/**
 * 口罩抽象工厂的层级
 */
public abstract class AbstractMaskFactory implements Factory{
    @Override
    public AbstractCar newCar(){
        return null;
    };

    @Override
    public abstract AbstractMask newMask();
}
