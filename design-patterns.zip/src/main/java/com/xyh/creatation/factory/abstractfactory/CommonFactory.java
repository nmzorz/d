package com.xyh.creatation.factory.abstractfactory;

public class CommonFactory extends AbstractMaskFactory {
    @Override
    public AbstractMask newMask() {
        return new CommonMask();
    }
}
