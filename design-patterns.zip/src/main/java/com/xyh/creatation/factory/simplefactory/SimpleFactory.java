package com.xyh.creatation.factory.simplefactory;
/**
 * 工厂模式（Factory Pattern）提供了一种创建对象的最佳方式。
 * 我们不必关心对象的创建细节，只需要根据不同情况获取不同产品即可。难点：写好我们的工厂
 *
 * 简单工厂：产品数量极少
 * 三个角色
 * Factory：工厂角色， SimpleFactory
 * Product：抽象产品角色，Car
 * ConcreteProduct：具体产品角色， VanCar、MiniCar
 */
public class SimpleFactory {

    public AbstractCar newCar(String type) {
        //核心方法：一切从简
        if ("van".equals(type)) {
            return new VanCar();
        }
        if ("mini".equals(type)) {
            return new MiniCar();
        }
        //更多的产品，违反开闭原则。应该直接扩展出一个类来造
        return null;
    }
}
