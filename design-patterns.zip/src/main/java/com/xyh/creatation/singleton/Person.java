package com.xyh.creatation.singleton;

/**
 * 一个单一的类，负责创建自己的对象，同时确保系统中只有单个对象被创建。
 *
 * 单例特点:
 *      某个类只能有一个实例；（构造器私有）
 *      它必须自行创建这个实例；（自己编写实例化逻辑）
 *      它必须自行向整个系统提供这个实例；（对外提供实例化方法）
 *
 * 什么场景用到？
 *      多线程中的线程池
 *      数据库的连接池
 *      系统环境信息
 *      上下文（ServletContext）
 *      ......
 */
public class Person {

    private volatile static Person instance;
    private final static Person instance2 = new Person();

    private Person() {
        System.out.println("创建了");
    }
    private Person(String s) {
        System.out.println(s+"创建了");
    }

    public static Person getKunkun() {
        if (instance == null) {
            instance = new Person();
        }
        return instance;
    }

    public static Person getKunkun(String s) {
        if (instance == null) {
            instance = new Person(s);
        }
        return instance;
    }

    /**
     * 双重检查锁+内存可见性
     * @param s
     * @return
     */
    public static Person threadGet(String s) {
        if (instance == null) {
            synchronized (Person.class) {
                if (instance == null) {
                    instance = new Person(s);
                }
            }
        }
        return instance;
    }

    public static Person getKunkun2() {
        return instance;
    }






}
