package com.xyh.creatation.singleton;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class SingletonTest {
    public static void main(String[] args) throws InterruptedException {
//        Person person = new Person();不能new
//        m1();

//        m2();

        m3();

    }

    private static void m3() throws InterruptedException {
        Set<Person> set = new HashSet<>();
        Thread t1 = new Thread(() -> {
            set.add(Person.threadGet("t1"));
        });
        Thread t2 = new Thread(() -> {
            set.add(Person.threadGet("t2"));
        });
        Thread t3 = new Thread(() -> {
            set.add(Person.threadGet("t3"));
        });

        t1.start();
        t2.start();
        t3.start();
        TimeUnit.MILLISECONDS.sleep(100);
        System.out.println(set);
    }
    private static void m2() throws InterruptedException {
        Set<Person> set = new HashSet<>();
        Thread t1 = new Thread(() -> {
            set.add(Person.getKunkun("t1"));
        });
        Thread t2 = new Thread(() -> {
            set.add(Person.getKunkun("t2"));
        });
        Thread t3 = new Thread(() -> {
            set.add(Person.getKunkun("t3"));
        });

        t1.start();
        t2.start();
        t3.start();
        TimeUnit.MILLISECONDS.sleep(100);
        System.out.println(set);
    }

    private static void m1() {
        Person kunkun1 = Person.getKunkun();
        Person kunkun2 = Person.getKunkun();
        System.out.println(kunkun1);
        System.out.println(kunkun2);
        System.out.println(kunkun1==kunkun2);

        Person kunkun3 = Person.getKunkun2();
        Person kunkun4 = Person.getKunkun2();
        System.out.println(kunkun3==kunkun4);
    }
}
