package com.xyh.creatation.buider;

/**
 * 产品角色（Product）：Phone
 * 抽象建造者（Builder）：AbstractPhoneBuilder
 * 具体建造者(Concrete Builder）：PhoneBuilder
 * 创建的东西细节复杂，还必须暴露给使用者。屏蔽过程而不屏蔽细节
 */
public class BuiderTest {
    public static void main(String[] args) {
        Phone phone = Phone.builder()
                .cpu("晓龙888")
                .mem("12")
                .build();
        System.out.println(phone);

        Phonelombok phonelombok = Phonelombok.builder()
                .cpu("晓龙888")
                .mem("12")
                .build();
        System.out.println(phonelombok);
    }
}
