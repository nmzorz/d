package com.xyh.creatation.buider;

public abstract class AbstractBuilder {

    Phone phone;

    abstract AbstractBuilder cpu(String cpu);
    abstract AbstractBuilder mem(String mem);

    Phone build(){
        return phone;
    };

}
