package com.xyh.creatation.buider;

import lombok.Builder;
import lombok.ToString;

@Builder
@ToString
public class Phonelombok {
    protected String cpu;
    protected String mem;
}
