package com.xyh.creatation.buider;

import lombok.ToString;

@ToString
public class Phone {
    protected String cpu;
    protected String mem;

    public static AbstractBuilder builder(){
        return new Builder();
    }

    static class Builder extends AbstractBuilder{

        public Builder() {
            phone = new Phone();
        }

        @Override
        AbstractBuilder cpu(String cpu) {
            phone.cpu = cpu;
            return this;
        }

        @Override
        AbstractBuilder mem(String mem) {
            phone.mem = mem;
            return this;
        }
    }
}
